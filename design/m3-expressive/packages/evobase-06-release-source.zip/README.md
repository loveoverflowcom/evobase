# Preview / release / evolution

Design/planning only; no implementation or provider evidence.

Preview zero delivery, immutable checked release, impact/backfill/recovery trước activation.

## Screens
- view-builder
- preview
- publish
- migration

## Sequential prompts
- docs/work-plan/070-release-and-preview.md
- docs/work-plan/080-schema-evolution.md

## Acceptance
- [ ] Draft edits never activate; preview no live writes/no external dispatch
- [ ] AppSpec/model/data/binding/policy revisions separate; app instance pins release
- [ ] Type/required/backfill impact preview + atomic cutover/recovery proof; no-DDL still migration
- [ ] Live runs keep pinned version; rollback/restore does not unsend/replay effects or revive revoked grants

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.

## Entry points in this scoped ZIP
- source/index.html: scoped fixture prototype (use an approved static server; no external calls). The first included screen is the default. Links to absent screens explain the separate pack.
- source/tokens.json + tokens.css + style.css + app.mjs: editable canonical theme/components.
- frames/: editable SVG for these screens only.
- Static PNG previews are separately pinned inline in the GitHub issue and in the design branch previews folder; this light source ZIP omits rasters.
- specs/component-contract.md, specs/accessibility-and-states.md and specs/source-to-design.md: shared contracts and evidence limits.
- build.py regenerates local token CSS/fixture data/contact sheets from the scoped source; render_static.py rerenders using a portable ROOT-derived font config.
- assets/: original vector assets, bundled Apache-2.0 fonts/license/notice.

Other packs, global contact sheets and the global issue index are available on the dedicated design branch, not included here.
