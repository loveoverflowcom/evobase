export const screens = [
  {
    "id": "workspace",
    "pack": "01-foundation",
    "surface": "Workspace",
    "section": "Ứng dụng",
    "kind": "hub",
    "title": "Một nơi cho công việc",
    "kicker": "KHÔNG GIAN / KHÔNG GIAN BÁN HÀNG",
    "description": "Bắt đầu từ bảng. Tạo công cụ vừa với đội của bạn.",
    "action": "Tạo ứng dụng",
    "status": "Không gian làm việc",
    "sections": [
      [
        "Bán hàng",
        "4 bảng · 3 chế độ xem · Draft 12",
        "Tiếp tục xây dựng"
      ],
      [
        "Vận hành",
        "Phiên bản 1.2 · Hosted",
        "Mở Runtime"
      ],
      [
        "Thư viện mẫu",
        "Định nghĩa không chứa dữ liệu khách hàng",
        "Khám phá mẫu"
      ]
    ],
    "note": "Định nghĩa ứng dụng, dữ liệu vận hành và kết nối tài khoản có vòng đời riêng."
  },
  {
    "id": "new-app",
    "pack": "01-foundation",
    "surface": "Workspace",
    "section": "Ứng dụng",
    "kind": "form",
    "title": "Bắt đầu với một bảng",
    "kicker": "ỨNG DỤNG MỚI",
    "description": "Chọn một nền tảng nhỏ, mở rộng khi công việc cần.",
    "action": "Tạo bản nháp",
    "status": "Chưa được xuất bản",
    "fields": [
      [
        "Tên ứng dụng",
        "Bán hàng"
      ],
      [
        "Bắt đầu từ",
        "Mẫu Khách hàng / Đơn hàng"
      ],
      [
        "Ngôn ngữ nhãn",
        "Tiếng Việt"
      ],
      [
        "Không gian sở hữu",
        "Bán hàng"
      ]
    ],
    "sections": [
      [
        "Mẫu có kiểu",
        "Customers, Products, Orders, OrderLines",
        "Stable IDs và Ref; dữ liệu ví dụ tùy chọn"
      ],
      [
        "Không gian trống",
        "Tự định nghĩa bảng đầu tiên",
        "Không cần SQL hoặc Rust"
      ]
    ],
    "note": "Tạo draft không tạo tenant database và không gửi thông báo."
  },
  {
    "id": "settings",
    "pack": "01-foundation",
    "surface": "Workspace",
    "section": "Cài đặt",
    "kind": "form",
    "title": "Vừa với cách bạn làm việc",
    "kicker": "TÀI KHOẢN / TRẢI NGHIỆM",
    "description": "Chọn giao diện, ngôn ngữ và mức chuyển động.",
    "action": "Lưu tùy chọn",
    "status": "Tùy chọn trên thiết bị",
    "fields": [
      [
        "Giao diện",
        "Theo hệ thống / Sáng / Tối"
      ],
      [
        "Ngôn ngữ",
        "Tiếng Việt"
      ],
      [
        "Chuyển động",
        "Theo hệ thống / Giảm chuyển động"
      ],
      [
        "Mật độ bảng",
        "Compact desktop / touch-safe mobile"
      ]
    ],
    "sections": [
      [
        "Quyền tài khoản",
        "Do host quản lý",
        "Không tự cấp admin từ AppSpec"
      ],
      [
        "Phiên làm việc",
        "Session expired giữ unsent draft",
        "Reauthenticate rồi kiểm quyền mới"
      ]
    ],
    "note": "Dynamic color tùy chọn về sau; semantic error/warning/success phải giữ nghĩa và contrast."
  },
  {
    "id": "states",
    "pack": "01-foundation",
    "surface": "Workspace",
    "section": "Trạng thái",
    "kind": "states",
    "title": "Mọi điểm dừng đều có lối ra",
    "kicker": "GLOBAL STATES / ERROR & RECOVERY",
    "description": "Lỗi không xóa nháp. Trạng thái không giả thành thành công.",
    "action": "Thử lại trong fixture",
    "status": "Design-only state catalogue",
    "sections": [
      [
        "Không có quyền",
        "Không lộ tên record ẩn",
        "Quay lại view có quyền · không request broad access"
      ],
      [
        "Chưa có dữ liệu",
        "Tạo bản ghi đầu tiên",
        "Một CTA rõ, nội dung giải thích ngắn"
      ],
      [
        "Mất kết nối",
        "Giữ draft · chưa confirmed",
        "Tải lại current revision / retry idempotent"
      ],
      [
        "Phiên hết hạn",
        "Che dữ liệu nhạy cảm",
        "Giữ unsent draft, recheck auth sau sign-in"
      ]
    ],
    "note": "Loading / empty / invalid / denied / saving / saved / conflict / offline / unknown outcome là các trạng thái riêng."
  },
  {
    "id": "components",
    "pack": "01-foundation",
    "surface": "Workspace",
    "section": "Thành phần",
    "kind": "components",
    "title": "Một ngôn ngữ, hai nền tảng",
    "kicker": "M3 EXPRESSIVE / BLUE LEDGER",
    "description": "Tonal grouping, hierarchy rõ, shape có mục đích. Không thêm viền cho mọi card.",
    "action": "Primary action",
    "status": "Canonical token reference",
    "sections": [
      [
        "Actions & shapes",
        "Filled / tonal / text / connected group",
        "48dp touch · pressed shape morph · no hover-only control"
      ],
      [
        "Typed components",
        "RefChip / TypeBadge / FormulaField / Receipt",
        "Data density riêng, không dùng color làm nghĩa duy nhất"
      ],
      [
        "Containment",
        "Surface-low / surface / tonal inspector",
        "0 elevation mặc định · outline chỉ grid/focus/error"
      ],
      [
        "Feedback",
        "Focus 3px · reduced motion · live region",
        "Loading không làm đổi selected identity"
      ]
    ],
    "note": "Leptos adapters + CMP MaterialTheme đọc cùng tokens.json; chưa pin API Expressive experimental như stable."
  }
];
