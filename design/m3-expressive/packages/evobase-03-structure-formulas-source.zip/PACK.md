# Relations / formulas

Design/planning only; no implementation or provider evidence.

Quan hệ và biểu thức thuần cùng stable-ID binding; captured price khác live lookup.

## Screens
- relations
- formula

## Sequential prompts
- docs/work-plan/040-relations-and-formulas.md

## Acceptance
- [ ] Baseline N:1 + restrict có conformance; 1:1/N:M disabled đến khi test/gate đạt
- [ ] Không hai canonical directions; edges/indexes projection có consistency proof
- [ ] Formula type/resource bounds; computed output policy, không partial visible-child total giả
- [ ] Rename/reorder/label đổi vẫn giữ nghĩa; targeted differential/golden tests

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
