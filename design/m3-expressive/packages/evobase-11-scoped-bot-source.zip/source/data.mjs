export const screens = [
  {
    "id": "bot-scope",
    "pack": "11-scoped-bot",
    "surface": "Builder",
    "section": "Kết nối",
    "kind": "policy",
    "title": "Trợ lý được làm những gì?",
    "kicker": "SERVICE ACTOR / SALES ASSISTANT",
    "description": "Chọn dữ liệu được đọc và hành động cần người xác nhận.",
    "action": "Lưu scope của bot",
    "status": "Chưa kết nối mô hình",
    "fields": [
      [
        "Projection được đọc",
        "Products.public · Orders.owned"
      ],
      [
        "Command được gọi",
        "CreateOrderDraft"
      ],
      [
        "Command bị cấm",
        "MarkPaid · UpdatePolicy · credentials"
      ],
      [
        "Rủi ro cao",
        "Human approval theo app policy"
      ]
    ],
    "sections": [
      [
        "Identity khách hàng",
        "Liên kết phải được xác thực",
        "Display name không là identity"
      ],
      [
        "Retrieved content",
        "Untrusted input",
        "Không nâng quyền tool từ nội dung message"
      ],
      [
        "Budgets và consent",
        "Tenant / model / index scope",
        "Current permissions áp trên cache và search"
      ]
    ],
    "note": "Bot không tự sửa inventory hoặc policy. Không dùng toàn VOT monorepo làm dependency."
  }
];
