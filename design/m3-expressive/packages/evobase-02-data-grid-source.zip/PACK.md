# Typed data / grid / import

Design/planning only; no implementation or provider evidence.

Kernel semantics trước grid. Bảng có kiểu và Ref hiển thị nhãn, lưu identity; import cần resolve.

## Screens
- builder-data
- field-inspector
- import-resolve

## Sequential prompts
- docs/work-plan/020-appspec-kernel.md
- docs/work-plan/030-typed-grid-and-import.md

## Acceptance
- [ ] Golden codec/ID/type/Ref round-trip vectors độc lập GUI/SQL
- [ ] Ref wrong table/missing/ambiguous/cross-scope bị chặn; reverse derived
- [ ] Grid keyboard/IME/paste/sort/rename không selection drift; currency unit rõ
- [ ] Cần hiện receipt/revision và lỗi theo ô, không giả save success

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
