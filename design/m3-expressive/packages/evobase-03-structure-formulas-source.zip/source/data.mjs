export const screens = [
  {
    "id": "relations",
    "pack": "03-structure-formulas",
    "surface": "Builder",
    "section": "Cấu trúc & Quan hệ",
    "kind": "relations",
    "title": "Các bảng kết nối ra sao?",
    "kicker": "CẤU TRÚC / 4 BẢNG CÓ KIỂU",
    "description": "Liên kết để thông tin đi cùng nhau, không cần nhập lại.",
    "action": "Thêm quan hệ",
    "status": "4 bảng · bản nháp",
    "sections": [
      [
        "Customers",
        "name · email · owner",
        "Orders ← reverse(Orders.customer)"
      ],
      [
        "Orders",
        "customer: Ref · state: Enum",
        "total := sum(lines.amount)"
      ],
      [
        "OrderLines",
        "order: Ref · product: Ref",
        "qty · captured_unit_price · amount"
      ],
      [
        "Products",
        "name · price · active",
        "Giá hiện tại không đổi giá đã chốt"
      ]
    ],
    "inspector": [
      [
        "Orders.customer",
        "N:1 → Customers"
      ],
      [
        "Delete",
        "Restrict"
      ],
      [
        "1:1 / Một-một",
        "Mục tiêu sau gate · chưa bật"
      ],
      [
        "N:M / Nhiều-nhiều",
        "Mục tiêu sau gate · chưa bật"
      ],
      [
        "Ref scope",
        "Cùng tenant + app instance"
      ]
    ],
    "note": "Không duy trì hai chiều canonical. Relation không tự sinh policy."
  },
  {
    "id": "formula",
    "pack": "03-structure-formulas",
    "surface": "Builder",
    "section": "Cấu trúc & Quan hệ",
    "kind": "editor",
    "title": "Tính tổng từ các dòng đơn",
    "kicker": "ORDERS / TOTAL",
    "description": "Chọn dữ liệu nguồn, phép tính và kiểm tra kết quả.",
    "action": "Áp dụng công thức",
    "status": "Công thức mẫu hợp lệ",
    "fields": [
      [
        "Tên cột kết quả",
        "Tổng cộng"
      ],
      [
        "Kiểu kết quả",
        "Tiền · VND"
      ],
      [
        "Dữ liệu nguồn",
        "Các dòng đơn → Thành tiền"
      ],
      [
        "Phép tính",
        "Tổng (SUM)"
      ]
    ],
    "sections": [
      [
        "Thử với ORD-1048",
        "3 dòng · 12.480.000 ₫",
        "Giá trong đơn giữ nguyên khi giá sản phẩm đổi"
      ],
      [
        "Khi không được phép xem",
        "Hiển thị Không có quyền",
        "Không giả một tổng chưa đầy đủ"
      ],
      [
        "Xem biểu thức nâng cao",
        "sum(lines.amount)",
        "Tên bảng/cột liên kết bằng mã cố định"
      ]
    ],
    "note": "Syntax minh họa; parser/subset phải được chốt bằng kernel ADR và golden tests."
  }
];
