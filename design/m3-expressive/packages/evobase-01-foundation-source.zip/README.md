# Foundation / M3 Expressive shells

Design/planning only; no implementation or provider evidence.

Thống nhất AppSpec/host boundaries, source tokens, adaptive shells và trạng thái phiên. Provider sign-in journey chờ identity ADR.

## Screens
- workspace
- new-app
- settings
- states
- components

## Sequential prompts
- docs/work-plan/010-contracts-and-bootstrap.md

## Acceptance
- [ ] Token source→generated output→mounted consumer trace; không fork palette
- [ ] Workspace/Builder/Runtime navigation separate; compact Builder read-only summary
- [ ] Light/dark, focus, VI/EN, reduced motion, zoom/text-scale evidence
- [ ] Denied/session-expired giữ unsent draft; không coi settings là auth journey hoàn chỉnh

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.

## Entry points in this scoped ZIP
- source/index.html: scoped fixture prototype (use an approved static server; no external calls). The first included screen is the default. Links to absent screens explain the separate pack.
- source/tokens.json + tokens.css + style.css + app.mjs: editable canonical theme/components.
- frames/: editable SVG for these screens only.
- Static PNG previews are separately pinned inline in the GitHub issue and in the design branch previews folder; this light source ZIP omits rasters.
- specs/component-contract.md, specs/accessibility-and-states.md and specs/source-to-design.md: shared contracts and evidence limits.
- build.py regenerates local token CSS/fixture data/contact sheets from the scoped source; render_static.py rerenders using a portable ROOT-derived font config.
- assets/: original vector assets, bundled Apache-2.0 fonts/license/notice.

Other packs, global contact sheets and the global issue index are available on the dedicated design branch, not included here.
