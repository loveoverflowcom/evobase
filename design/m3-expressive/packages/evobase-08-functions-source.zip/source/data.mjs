export const screens = [
  {
    "id": "functions",
    "pack": "08-functions",
    "surface": "Builder",
    "section": "Hành động & Quy trình",
    "kind": "flow",
    "title": "Đơn gửi đi, đúng người duyệt",
    "kicker": "QUY TRÌNH / DUYỆT ĐƠN HÀNG",
    "description": "Kết nối các bước, điều kiện và xử lý khi quá hạn.",
    "action": "Mô phỏng quy trình",
    "status": "Quy trình mẫu · chưa chạy thật",
    "steps": [
      [
        "Trigger",
        "OrderSubmitted · typed event"
      ],
      [
        "Điều kiện",
        "total > approval_threshold"
      ],
      [
        "Command",
        "CreateApprovalTask(order)"
      ],
      [
        "Enqueue",
        "Email notification · consent required"
      ],
      [
        "Wait",
        "Approve / Reject / Deadline"
      ],
      [
        "Transition",
        "Checked command + receipt"
      ]
    ],
    "inspector": [
      [
        "Retry",
        "Transient · bounded backoff"
      ],
      [
        "Timeout",
        "24h · branch riêng"
      ],
      [
        "Failure",
        "Quarantine / operator"
      ],
      [
        "Collection",
        "Bounded · no recursion"
      ],
      [
        "Preview",
        "Zero external delivery"
      ]
    ],
    "note": "Core không I/O. Internal at-least-once + idempotency; external exactly-once không được hứa."
  },
  {
    "id": "run-detail",
    "pack": "08-functions",
    "surface": "Runtime",
    "section": "Tự động hóa",
    "kind": "timeline",
    "title": "Cần xác minh trạng thái gửi",
    "kicker": "RUN / RUN-019 · PHIÊN BẢN 1.2",
    "description": "Tin nhắn có thể đã gửi. Kiểm tra kết quả trước khi gửi lại.",
    "action": "Yêu cầu đối soát",
    "status": "Chưa rõ kết quả",
    "steps": [
      [
        "09:12:01",
        "Đơn hàng đã được gửi để duyệt"
      ],
      [
        "09:12:02",
        "Thông báo được đưa vào hàng chờ"
      ],
      [
        "09:12:03",
        "Chưa nhận được xác nhận từ dịch vụ gửi"
      ],
      [
        "Hiện tại",
        "Chưa rõ kết quả · không tự gửi lại"
      ],
      [
        "Tiếp theo",
        "Xác minh trước khi thử lại"
      ]
    ],
    "inspector": [
      [
        "Quy trình",
        "Phiên bản 1.2"
      ],
      [
        "Lần gửi",
        "Lần 1"
      ],
      [
        "Mã đối soát",
        "msg-204"
      ],
      [
        "Dừng gửi",
        "Không thu hồi tin đã gửi"
      ],
      [
        "Nguồn minh họa",
        "Dịch vụ gửi mô phỏng"
      ]
    ],
    "note": "Validation/permanent error không retry vô hạn. Manual retry có quyền/audit và receipt."
  }
];
