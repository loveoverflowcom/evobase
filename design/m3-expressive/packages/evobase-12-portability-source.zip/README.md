# Local profile / recovery

Design/planning only; no implementation or provider evidence.

ADR support envelope cho portable execution, local unsent draft và restore.

## Screens
- offline

## Sequential prompts
- docs/work-plan/140-portability-recovery.md

## Acceptance
- [ ] Bounded codec/version/provenance and stable identity compatibility, .evobase extension ADR
- [ ] Local snapshot does not grant hosted authority; no falsely confirmed offline send
- [ ] Conflict needs review; reauth/revalidation/current permissions at sync
- [ ] Restore/export/receipts test: no revoked-grant resurrection or arbitrary external replay

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.

## Entry points in this scoped ZIP
- source/index.html: scoped fixture prototype (use an approved static server; no external calls). The first included screen is the default. Links to absent screens explain the separate pack.
- source/tokens.json + tokens.css + style.css + app.mjs: editable canonical theme/components.
- frames/: editable SVG for these screens only.
- Static PNG previews are separately pinned inline in the GitHub issue and in the design branch previews folder; this light source ZIP omits rasters.
- specs/component-contract.md, specs/accessibility-and-states.md and specs/source-to-design.md: shared contracts and evidence limits.
- build.py regenerates local token CSS/fixture data/contact sheets from the scoped source; render_static.py rerenders using a portable ROOT-derived font config.
- assets/: original vector assets, bundled Apache-2.0 fonts/license/notice.

Other packs, global contact sheets and the global issue index are available on the dedicated design branch, not included here.
