export const screens = [
  {
    "id": "view-builder",
    "pack": "06-release",
    "surface": "Builder",
    "section": "Chế độ xem",
    "kind": "review",
    "title": "Chỉ hiện điều người dùng cần",
    "kicker": "VIEW / SALES WORKSPACE",
    "description": "Ghép List, Detail và Form từ định nghĩa đã kiểm.",
    "action": "Mở preview Runtime",
    "status": "Preview theo actor mẫu",
    "sections": [
      [
        "Danh sách đơn hàng",
        "Mã đơn · Khách hàng · Tổng · Trạng thái",
        "Sort: cập nhật gần nhất · page size có giới hạn"
      ],
      [
        "Form tạo đơn",
        "Customer picker · các dòng sản phẩm",
        "Quyền và validation từ core"
      ],
      [
        "Hành động",
        "Submit / Approve theo khả năng",
        "Không render nút không có quyền"
      ]
    ],
    "inspector": [
      [
        "Surface",
        "Runtime"
      ],
      [
        "Primary view",
        "Orders / List"
      ],
      [
        "Mobile",
        "List-detail / bottom sheet"
      ],
      [
        "Ẩn field",
        "Transport vẫn enforce policy"
      ]
    ],
    "note": "Ẩn ở UI không phải bảo mật. Các field system receipt/provider không editable qua generic grid."
  },
  {
    "id": "preview",
    "pack": "06-release",
    "surface": "Builder",
    "section": "Xuất bản",
    "kind": "review",
    "title": "Thử trước, không gửi thật",
    "kicker": "PREVIEW / BẢN NHÁP 12",
    "description": "Dùng dữ liệu mẫu để kiểm tra màn hình, quyền và quy trình.",
    "action": "Chạy 6 tình huống mẫu",
    "status": "MÔ PHỎNG · không gửi thông báo",
    "sections": [
      [
        "Tạo và gửi đơn",
        "Typed guards / captured price",
        "Fixture · không ghi tenant live"
      ],
      [
        "Đọc đơn người khác",
        "Deny theo policy",
        "Kiểm relation picker, lookup và export"
      ],
      [
        "Approval quá hạn",
        "Timer và error branch mô phỏng",
        "Không dùng connector live"
      ],
      [
        "Đổi phiên bản",
        "Run v1 giữ plan v1",
        "Kiểm release và binding tách biệt"
      ]
    ],
    "inspector": [
      [
        "Actor",
        "An · SalesRep (fixture)"
      ],
      [
        "Release",
        "Draft 12"
      ],
      [
        "Host effects",
        "Disabled"
      ],
      [
        "Kiểm chứng",
        "Minh họa · chưa có test evidence"
      ],
      [
        "Evidence",
        "Không phải provider test"
      ]
    ],
    "note": "Thiết kế fixture không đồng nghĩa tests đã chạy. Kết quả runtime phải lấy từ test evidence thật."
  },
  {
    "id": "publish",
    "pack": "06-release",
    "surface": "Builder",
    "section": "Xuất bản",
    "kind": "review",
    "title": "Sẵn sàng đưa vào sử dụng?",
    "kicker": "RELEASE / 1.3.0 CANDIDATE",
    "description": "Xem thay đổi và điều kiện còn thiếu trước khi xuất bản.",
    "action": "Yêu cầu xuất bản",
    "status": "Còn 1 điều kiện cần hoàn tất",
    "sections": [
      [
        "Định nghĩa đã kiểm",
        "4 tables · 2 commands · 1 function",
        "Immutable release fingerprint"
      ],
      [
        "Tác động dữ liệu",
        "Thêm optional field · không backfill",
        "Không sinh business SQL table trong fixed-store subset"
      ],
      [
        "Binding của tenant",
        "Email chưa được cấp consent",
        "Tắt function gửi email khi chưa có binding"
      ],
      [
        "Điểm chặn",
        "Storage conformance chưa có evidence",
        "Không báo production-ready từ preview"
      ]
    ],
    "inspector": [
      [
        "AppSpec",
        "1.3.0"
      ],
      [
        "Tenant data revision",
        "Khác model version"
      ],
      [
        "Activation",
        "Atomic / có recovery plan"
      ],
      [
        "Runs đang chạy",
        "Pin release cũ"
      ],
      [
        "Rollback",
        "Không undo effect đã gửi"
      ]
    ],
    "note": "Template update không tự nâng mọi tenant. Từng app instance có release được pin riêng."
  },
  {
    "id": "migration",
    "pack": "06-release",
    "surface": "Builder",
    "section": "Xuất bản",
    "kind": "review",
    "title": "Kiểm tra trước khi đổi kiểu",
    "kicker": "SCHEMA EVOLUTION / IMPACT",
    "description": "Giải quyết dữ liệu bị ảnh hưởng trước khi áp dụng phiên bản mới.",
    "action": "Tạo kế hoạch migration",
    "status": "Chạy thử · chưa áp dụng",
    "sections": [
      [
        "Đổi field required",
        "customer: optional → required",
        "7 record thiếu giá trị cần giải quyết"
      ],
      [
        "Backfill có kiểm",
        "Map stable IDs và policy",
        "Không ghi đè field người dùng vừa sửa"
      ],
      [
        "Atomic activation",
        "Revalidate → cutover → fencing",
        "App instance giữ revision cũ nếu gate lỗi"
      ],
      [
        "Recovery",
        "Export / restore theo scope",
        "Không hồi sinh revoked grants hoặc replay effects"
      ]
    ],
    "inspector": [
      [
        "Ảnh hưởng",
        "7 / 148 orders (fixture)"
      ],
      [
        "Quyền",
        "Migration operator"
      ],
      [
        "Recovery",
        "Bắt buộc xác minh"
      ],
      [
        "Dữ liệu live",
        "Chưa chạm"
      ]
    ],
    "note": "Storage adapter/codec/format extension phải có ADR; không coi đổi đuôi file là migration."
  }
];
