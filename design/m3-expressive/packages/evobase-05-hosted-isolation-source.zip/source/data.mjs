export const screens = [
  {
    "id": "tenant-ops",
    "pack": "05-hosted-isolation",
    "surface": "Platform",
    "section": "Tenant & Lưu trữ",
    "kind": "ops",
    "title": "Cô lập có thể kiểm chứng",
    "kicker": "HOSTED / ISOLATION SPIKE",
    "description": "Định nghĩa chung, dữ liệu và binding riêng từng tenant.",
    "action": "Mở báo cáo conformance",
    "status": "Thiết kế spike · chưa provision",
    "sections": [
      [
        "Tenant A · Blueprint",
        "Database A / fixed engine layout",
        "Runtime role: no DDL, no BYPASSRLS"
      ],
      [
        "Tenant B · Northstar",
        "Database B / same AppSpec release",
        "Field/policy ở A không thay B"
      ],
      [
        "Resource budgets",
        "Bounded pools · fair scheduling",
        "DB riêng trong cùng cluster vẫn chia CPU / I/O"
      ],
      [
        "Negative evidence",
        "API · refs · subscriptions · cache · blobs",
        "Không quảng cáo hard/physical isolation"
      ]
    ],
    "inspector": [
      [
        "Quyền",
        "Platform operator"
      ],
      [
        "Provisioning",
        "Vai trò riêng runtime"
      ],
      [
        "Adapter",
        "Đề xuất; ADR sau đo"
      ],
      [
        "Backup",
        "Scoped; không hứa tenant PITR"
      ],
      [
        "Secrets",
        "Chỉ handle, không portable"
      ]
    ],
    "note": "Chỉ operator thấy màn này. Tenant ID do host xác thực; không dựa request body để chọn credentials."
  }
];
