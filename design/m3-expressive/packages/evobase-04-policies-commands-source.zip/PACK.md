# Authority / policy / commands

Design/planning only; no implementation or provider evidence.

Câu cấu trúc dễ hiểu với current authority, guards và typed receipt.

## Screens
- policy
- command

## Sequential prompts
- docs/work-plan/050-authority-policies-commands.md

## Acceptance
- [ ] Host boundary AND current grants AND app policy AND restrictions; missing context deny
- [ ] Relation/picker/join/export/aggregate không ngầm mở quyền
- [ ] Old+new state và field mutability kiểm tại command commit
- [ ] Request key binds immutable intent; exact retry returns original receipt under current grants; no effect duplication

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
