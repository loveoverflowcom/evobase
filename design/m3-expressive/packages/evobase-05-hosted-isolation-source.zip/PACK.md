# Isolated fixed-store spike

Design/planning only; no implementation or provider evidence.

Đo fixed-layout engine store và database-per-tenant, giữ lựa chọn ADR chưa settled production.

## Screens
- tenant-ops

## Sequential prompts
- docs/work-plan/060-isolated-fixed-store.md

## Acceptance
- [ ] Hai tenant DB + provisioner/runtime role separation; runtime no DDL/BYPASSRLS
- [ ] Thêm logical table/optional field/Ref/publish không business SQL DDL; actual catalog evidence
- [ ] Records/edges/index/unique/revision/outbox atomic; concurrency/restart/failure vectors
- [ ] Tenant negative tests gồm API/Ref/cache/subscription/blob/log/bot; resource/latency measurements + support envelope ADR

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
