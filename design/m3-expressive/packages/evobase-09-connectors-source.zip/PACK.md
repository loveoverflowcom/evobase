# Email / webhook capability bindings

Design/planning only; no implementation or provider evidence.

Contract capabilities thực, host account/consent/secret handles riêng definition.

## Screens
- connectors

## Sequential prompts
- docs/work-plan/110-connectors.md

## Acceptance
- [ ] Email fake provider labeled simulated; real-target evidence only after authorized test
- [ ] Verified webhook/dedup/tenant correlation; payload cannot grant actor or tenant
- [ ] Secret handles/accounts chỉ ở host bindings; portable definition chỉ abstract connector contracts, không host-secret binding; egress/consent recheck
- [ ] Zalo separate adapter spike/permissions; unsupported disabled; phone number not automatic valid recipient

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
