# Scoped service-actor bot

Design/planning only; no implementation or provider evidence.

Allowed projections/commands, budgets, consent và human approval.

## Screens
- bot-scope

## Sequential prompts
- docs/work-plan/130-scoped-bot.md

## Acceptance
- [ ] Verified identity linking; display name not authority
- [ ] Retrieved content untrusted; no permission elevation/tool instruction from messages
- [ ] Bot cannot MarkPaid/change inventory/policy/credentials without app policy and authorized command
- [ ] Index/search/cache/history tenant+current-grant scope, prompt injection/denied/no-model-binding tests

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
