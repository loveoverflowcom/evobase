export const screens = [
  {
    "id": "builder-data",
    "pack": "02-data-grid",
    "surface": "Builder",
    "section": "Bảng dữ liệu",
    "kind": "grid",
    "title": "Đơn hàng",
    "kicker": "BÁN HÀNG / BẢN NHÁP 12",
    "description": "Liên kết khách hàng và theo dõi đơn trong bản nháp của bạn.",
    "action": "Thêm bản ghi mẫu",
    "status": "Đã lưu bản nháp",
    "columns": [
      "Mã đơn",
      "Khách hàng ↗",
      "Trạng thái",
      "Tổng (VND) ƒ",
      "Phụ trách"
    ],
    "rows": [
      [
        "ORD-1048",
        "Minh An",
        "Đã gửi",
        "12.480.000 ₫",
        "Linh"
      ],
      [
        "ORD-1047",
        "An Phú",
        "Nháp",
        "4.620.000 ₫",
        "Bạn"
      ],
      [
        "ORD-1046",
        "Hải Yến",
        "Đã duyệt",
        "8.950.000 ₫",
        "Linh"
      ],
      [
        "ORD-1045",
        "Đông Nam",
        "Nháp",
        "2.180.000 ₫",
        "Bạn"
      ],
      [
        "ORD-1044",
        "Bình Minh",
        "Đã gửi",
        "6.740.000 ₫",
        "An"
      ]
    ],
    "inspector": [
      [
        "KIỂU CỘT",
        "Liên kết → Khách hàng"
      ],
      [
        "Hiển thị",
        "Tên khách hàng"
      ],
      [
        "Bắt buộc",
        "Có"
      ],
      [
        "Khi xóa",
        "Chặn khi còn đơn"
      ],
      [
        "Chiều ngược",
        "Các đơn hàng (tự tạo)"
      ],
      [
        "Nâng cao",
        "field_customer · Ref<Customers>"
      ]
    ],
    "note": "Ô hiển thị nhãn, lưu record identity. Không mở quyền đọc chỉ vì có quan hệ."
  },
  {
    "id": "field-inspector",
    "pack": "02-data-grid",
    "surface": "Builder",
    "section": "Bảng dữ liệu",
    "kind": "form",
    "title": "Một cột, một ý nghĩa",
    "kicker": "ORDERS / KHÁCH HÀNG",
    "description": "Chọn kiểu và ràng buộc trước khi nhập dữ liệu.",
    "action": "Lưu cấu hình cột",
    "status": "Thay đổi trong draft",
    "fields": [
      [
        "Tên cột",
        "Khách hàng"
      ],
      [
        "Kiểu dữ liệu",
        "Liên kết đến bảng Khách hàng"
      ],
      [
        "Hiển thị bằng",
        "Tên khách hàng"
      ],
      [
        "Số bản ghi được chọn",
        "Một khách hàng cho mỗi đơn"
      ],
      [
        "Bắt buộc chọn",
        "Có"
      ],
      [
        "Khi xóa khách hàng",
        "Chặn nếu vẫn còn đơn hàng"
      ]
    ],
    "sections": [
      [
        "Giữ nguyên liên kết",
        "Đổi tên hoặc kéo cột không làm mất liên kết",
        "Mã cố định được giữ phía sau"
      ],
      [
        "Danh sách chọn",
        "Chỉ những khách hàng được phép xem",
        "Quyền của ứng dụng được kiểm tra khi chọn"
      ]
    ],
    "note": "Chuyển kiểu có dữ liệu cần impact preview; không đổi thầm sau một lần click."
  },
  {
    "id": "import-resolve",
    "pack": "02-data-grid",
    "surface": "Builder",
    "section": "Bảng dữ liệu",
    "kind": "review",
    "title": "Khớp đúng trước khi nhập",
    "kicker": "IMPORT / KIỂM TRA THAM CHIẾU",
    "description": "Hai tên bị trùng. Chọn record đúng hoặc bỏ dòng đó.",
    "action": "Tiếp tục 28 dòng hợp lệ",
    "status": "2 dòng cần giải quyết",
    "sections": [
      [
        "Dòng 12 · Minh An",
        "2 mục tiêu cùng tên",
        "CUS-008 · Minh An / Hà Nội"
      ],
      [
        "Dòng 19 · Đại Lộc",
        "Không tìm thấy record hợp lệ",
        "Tạo riêng hoặc bỏ dòng; không đoán Ref"
      ],
      [
        "28 dòng đã kiểm",
        "Kiểu và ràng buộc hợp lệ",
        "Chưa ghi vào Runtime"
      ]
    ],
    "inspector": [
      [
        "Nguồn",
        "customers-demo.csv (fixture)"
      ],
      [
        "Mapping",
        "Khách hàng → field_customer"
      ],
      [
        "Cách ghi",
        "Bản nháp / dữ liệu mẫu"
      ],
      [
        "Lỗi",
        "Không có phép tự chọn"
      ]
    ],
    "note": "Paste và IME phải giữ text đến khi commit; lỗi theo ô/dòng, undo có ranh giới rõ."
  }
];
