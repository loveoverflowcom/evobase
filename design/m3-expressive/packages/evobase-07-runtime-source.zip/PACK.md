# Runtime web / CMP

Design/planning only; no implementation or provider evidence.

List-detail/form/approval có phép; mobile ưu tiên việc thực cần làm, không modeling trên phone.

## Screens
- runtime-home
- runtime-detail
- runtime-form
- approval

## Sequential prompts
- docs/work-plan/090-runtime-web-cmp.md

## Acceptance
- [ ] Only authorized projection/actions render; trusted runtime still enforces
- [ ] Save draft vs Submit distinct; receipt/revision/conflict/no-false-sent semantics
- [ ] Approval old+new/current grants and reviewed revision; reject explicit; Close/Back not decision
- [ ] Visible navigation-up, Android Back/iOS edge/browser history/IME/safe-area + native CMP evidence separate from mobile Web

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
