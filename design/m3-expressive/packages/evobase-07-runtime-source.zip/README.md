# Runtime web / CMP

Design/planning only; no implementation or provider evidence.

List-detail/form/approval có phép; mobile ưu tiên việc thực cần làm, không modeling trên phone.

## Screens
- runtime-home
- runtime-detail
- runtime-form
- approval

## Sequential prompts
- docs/work-plan/090-runtime-web-cmp.md

## Acceptance
- [ ] Only authorized projection/actions render; trusted runtime still enforces
- [ ] Save draft vs Submit distinct; receipt/revision/conflict/no-false-sent semantics
- [ ] Approval old+new/current grants and reviewed revision; reject explicit; Close/Back not decision
- [ ] Visible navigation-up, Android Back/iOS edge/browser history/IME/safe-area + native CMP evidence separate from mobile Web

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.

## Entry points in this scoped ZIP
- source/index.html: scoped fixture prototype (use an approved static server; no external calls). The first included screen is the default. Links to absent screens explain the separate pack.
- source/tokens.json + tokens.css + style.css + app.mjs: editable canonical theme/components.
- frames/: editable SVG for these screens only.
- Static PNG previews are separately pinned inline in the GitHub issue and in the design branch previews folder; this light source ZIP omits rasters.
- specs/component-contract.md, specs/accessibility-and-states.md and specs/source-to-design.md: shared contracts and evidence limits.
- build.py regenerates local token CSS/fixture data/contact sheets from the scoped source; render_static.py rerenders using a portable ROOT-derived font config.
- assets/: original vector assets, bundled Apache-2.0 fonts/license/notice.

Other packs, global contact sheets and the global issue index are available on the dedicated design branch, not included here.
