# Typed data / grid / import

Design/planning only; no implementation or provider evidence.

Kernel semantics trước grid. Bảng có kiểu và Ref hiển thị nhãn, lưu identity; import cần resolve.

## Screens
- builder-data
- field-inspector
- import-resolve

## Sequential prompts
- docs/work-plan/020-appspec-kernel.md
- docs/work-plan/030-typed-grid-and-import.md

## Acceptance
- [ ] Golden codec/ID/type/Ref round-trip vectors độc lập GUI/SQL
- [ ] Ref wrong table/missing/ambiguous/cross-scope bị chặn; reverse derived
- [ ] Grid keyboard/IME/paste/sort/rename không selection drift; currency unit rõ
- [ ] Cần hiện receipt/revision và lỗi theo ô, không giả save success

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.

## Entry points in this scoped ZIP
- source/index.html: scoped fixture prototype (use an approved static server; no external calls). The first included screen is the default. Links to absent screens explain the separate pack.
- source/tokens.json + tokens.css + style.css + app.mjs: editable canonical theme/components.
- frames/: editable SVG for these screens only.
- Static PNG previews are separately pinned inline in the GitHub issue and in the design branch previews folder; this light source ZIP omits rasters.
- specs/component-contract.md, specs/accessibility-and-states.md and specs/source-to-design.md: shared contracts and evidence limits.
- build.py regenerates local token CSS/fixture data/contact sheets from the scoped source; render_static.py rerenders using a portable ROOT-derived font config.
- assets/: original vector assets, bundled Apache-2.0 fonts/license/notice.

Other packs, global contact sheets and the global issue index are available on the dedicated design branch, not included here.
