export const screens = [
  {
    "id": "connectors",
    "pack": "09-connectors",
    "surface": "Builder",
    "section": "Kết nối",
    "kind": "connectors",
    "title": "Kết nối với công cụ bạn dùng",
    "kicker": "TÀI KHOẢN / KẾT NỐI",
    "description": "Chọn tài khoản, quyền gửi và mẫu nội dung.",
    "action": "Cấu hình Email",
    "status": "Chưa có tài khoản được kết nối",
    "sections": [
      [
        "Email",
        "Send / verified webhook / receipts",
        "Test dùng fake provider đến khi có consent"
      ],
      [
        "Webhook",
        "Signature + dedup + tenant correlation",
        "Payload không tự cấp tenant authority"
      ],
      [
        "Zalo",
        "Adapter spike cần permissions",
        "Không coi mọi số điện thoại là recipient hợp lệ"
      ],
      [
        "Field mapping",
        "Order.customer → allowed recipient",
        "Bind secret handle; không ghi token vào AppSpec"
      ]
    ],
    "inspector": [
      [
        "Account",
        "Chưa kết nối"
      ],
      [
        "Consent",
        "Chưa cấp"
      ],
      [
        "Test delivery",
        "Disabled"
      ],
      [
        "Egress",
        "Allowlisted host binding"
      ],
      [
        "Result",
        "Receipt / Unknown / permanent error"
      ]
    ],
    "note": "Preview không gửi thật. Provider capabilities phải phân biệt supported, simulated và unsupported."
  }
];
