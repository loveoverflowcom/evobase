# Business inbox / messaging

Design/planning only; no implementation or provider evidence.

Hộp thư có context với protected transport metadata.

## Screens
- inbox

## Sequential prompts
- docs/work-plan/120-messaging.md

## Acceptance
- [ ] Conversation/message/participant/delivery typed managed projections
- [ ] Provider IDs/receipts read-only; generic edit cannot fake delivered/received
- [ ] Scoped inbox/attachment/search + current output policy tests
- [ ] Draft message separate dispatch; unknown delivery clearly shown; no federation/E2EE requirement for MVP

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
