# Isolated fixed-store spike

Design/planning only; no implementation or provider evidence.

Đo fixed-layout engine store và database-per-tenant, giữ lựa chọn ADR chưa settled production.

## Screens
- tenant-ops

## Sequential prompts
- docs/work-plan/060-isolated-fixed-store.md

## Acceptance
- [ ] Hai tenant DB + provisioner/runtime role separation; runtime no DDL/BYPASSRLS
- [ ] Thêm logical table/optional field/Ref/publish không business SQL DDL; actual catalog evidence
- [ ] Records/edges/index/unique/revision/outbox atomic; concurrency/restart/failure vectors
- [ ] Tenant negative tests gồm API/Ref/cache/subscription/blob/log/bot; resource/latency measurements + support envelope ADR

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.

## Entry points in this scoped ZIP
- source/index.html: scoped fixture prototype (use an approved static server; no external calls). The first included screen is the default. Links to absent screens explain the separate pack.
- source/tokens.json + tokens.css + style.css + app.mjs: editable canonical theme/components.
- frames/: editable SVG for these screens only.
- Static PNG previews are separately pinned inline in the GitHub issue and in the design branch previews folder; this light source ZIP omits rasters.
- specs/component-contract.md, specs/accessibility-and-states.md and specs/source-to-design.md: shared contracts and evidence limits.
- build.py regenerates local token CSS/fixture data/contact sheets from the scoped source; render_static.py rerenders using a portable ROOT-derived font config.
- assets/: original vector assets, bundled Apache-2.0 fonts/license/notice.

Other packs, global contact sheets and the global issue index are available on the dedicated design branch, not included here.
