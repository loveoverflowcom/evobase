export const screens = [
  {
    "id": "offline",
    "pack": "12-portability",
    "surface": "Runtime",
    "section": "Đồng bộ",
    "kind": "review",
    "title": "Nháp của bạn vẫn được giữ",
    "kicker": "ĐỒNG BỘ / NGOẠI TUYẾN",
    "description": "Bạn đang mất kết nối. Thay đổi chưa được xác nhận trên máy chủ.",
    "action": "Xem 2 thay đổi chờ đồng bộ",
    "status": "Ngoại tuyến · 2 thay đổi chờ đồng bộ",
    "sections": [
      [
        "Đơn nháp chưa đồng bộ",
        "ORD-local-02 · đang lưu trên thiết bị",
        "Chưa gửi đơn hàng"
      ],
      [
        "Thay đổi cần giải quyết",
        "Đơn đã được chỉnh ở nơi khác",
        "Xem hai bản, chọn thay đổi muốn giữ"
      ],
      [
        "Xuất mẫu ứng dụng",
        "Mặc định không kèm dữ liệu riêng",
        "Tính năng sẽ bật khi kiểm định dạng hoàn tất"
      ],
      [
        "Khôi phục",
        "Kiểm tra bản sao và phạm vi",
        "Không tự gửi lại thông báo cũ"
      ]
    ],
    "inspector": [
      [
        "Kết nối",
        "Ngoại tuyến"
      ],
      [
        "Nháp đã giữ",
        "2 thay đổi"
      ],
      [
        "Gửi đơn hàng",
        "Chưa xác nhận"
      ],
      [
        "Tiếp theo",
        "Đăng nhập và kiểm lại khi có mạng"
      ]
    ],
    "note": "Offline/native không được quảng cáo hoàn chỉnh trước conformance và host seam evidence."
  }
];
