export const screens = [
  {
    "id": "runtime-home",
    "pack": "07-runtime",
    "surface": "Runtime",
    "section": "Đơn hàng",
    "kind": "runtime",
    "title": "Hôm nay cần làm gì?",
    "kicker": "KHÔNG GIAN BÁN HÀNG / SALES / PHIÊN BẢN 1.2",
    "description": "Công việc đang chờ bạn và những đơn hàng gần đây.",
    "action": "Tạo đơn hàng",
    "status": "Đã đồng bộ",
    "sections": [
      [
        "Cần bạn xử lý",
        "3 đơn đang chờ duyệt",
        "Mở danh sách công việc"
      ],
      [
        "Đơn hàng của bạn",
        "12 đơn đang hoạt động",
        "Gần nhất: ORD-1047 · An Phú"
      ],
      [
        "Dữ liệu gần đây",
        "Khách hàng và sản phẩm được phép",
        "Đọc theo policy hiện tại"
      ]
    ],
    "note": "Tenant được xác thực từ host context. Selector trên URL không tự cấp quyền.",
    "tasks": [
      [
        "ORD-1048",
        "Minh An",
        "12.480.000 ₫",
        "Hạn 16:30",
        "Linh",
        "Cần duyệt"
      ],
      [
        "ORD-1044",
        "Bình Minh",
        "6.740.000 ₫",
        "Hạn ngày mai",
        "An",
        "Cần duyệt"
      ]
    ],
    "recent": [
      [
        "ORD-1047",
        "An Phú",
        "4.620.000 ₫",
        "10 phút trước",
        "Bạn",
        "Nháp"
      ],
      [
        "ORD-1045",
        "Đông Nam",
        "2.180.000 ₫",
        "25 phút trước",
        "Bạn",
        "Nháp"
      ]
    ]
  },
  {
    "id": "runtime-detail",
    "pack": "07-runtime",
    "surface": "Runtime",
    "section": "Đơn hàng",
    "kind": "detail",
    "title": "ORD-1048",
    "kicker": "ĐƠN HÀNG / MINH AN",
    "description": "Đã gửi · Linh phụ trách · cập nhật 10 phút trước",
    "action": "Mở yêu cầu duyệt",
    "status": "Đã lưu",
    "fields": [
      [
        "Khách hàng",
        "Minh An"
      ],
      [
        "Tổng cộng",
        "12.480.000 ₫"
      ],
      [
        "Trạng thái",
        "Đã gửi"
      ],
      [
        "Phụ trách",
        "Linh"
      ]
    ],
    "sections": [
      [
        "Sản phẩm trong đơn",
        "3 sản phẩm · giá được giữ khi tạo đơn",
        "Xem số lượng và thành tiền"
      ],
      [
        "Lịch sử đơn",
        "Linh gửi đơn lúc 09:12",
        "Thông tin xác nhận chỉ được xem"
      ],
      [
        "Yêu cầu duyệt",
        "Đơn vượt mức cần phê duyệt",
        "Mở yêu cầu để xem quyết định"
      ]
    ],
    "note": "Đổi tên khách hàng không đổi identity; action luôn recheck current grants tại command commit."
  },
  {
    "id": "runtime-form",
    "pack": "07-runtime",
    "surface": "Runtime",
    "section": "Đơn hàng",
    "kind": "form",
    "title": "Tạo đơn hàng",
    "kicker": "ORDERS / NEW DRAFT",
    "description": "Chọn khách hàng rồi thêm sản phẩm. Bạn có thể lưu nháp trước.",
    "action": "Lưu đơn nháp",
    "status": "Chưa gửi",
    "fields": [
      [
        "Khách hàng *",
        "Chọn khách hàng được phép xem"
      ],
      [
        "Phụ trách",
        "Bạn"
      ],
      [
        "Sản phẩm *",
        "Bàn làm việc"
      ],
      [
        "Số lượng *",
        "2"
      ],
      [
        "Đơn giá trong đơn",
        "2.310.000 ₫ · giữ nguyên sau khi lưu"
      ],
      [
        "Ghi chú",
        "Giao trong giờ làm việc"
      ]
    ],
    "sections": [
      [
        "Tổng tạm tính",
        "4.620.000 ₫",
        "Tổng được kiểm tra lại khi lưu"
      ],
      [
        "Lưu trước, gửi sau",
        "Lưu nháp không gửi đơn hàng",
        "Khi mất mạng, hiển thị chưa đồng bộ"
      ]
    ],
    "note": "Lưu nháp và Submit là hai command khác. Không tự gửi đơn khi bấm Save."
  },
  {
    "id": "approval",
    "pack": "07-runtime",
    "surface": "Runtime",
    "section": "Công việc",
    "kind": "detail",
    "title": "Duyệt đơn ORD-1048",
    "kicker": "APPROVAL / ORD-1048",
    "description": "Linh gửi yêu cầu · cần quyết định trước 16:30",
    "action": "Duyệt đơn",
    "status": "Chờ bạn duyệt",
    "fields": [
      [
        "Giá trị đơn",
        "12.480.000 ₫"
      ],
      [
        "Khách hàng",
        "Minh An"
      ],
      [
        "Người yêu cầu",
        "Linh"
      ],
      [
        "Lý do cần duyệt",
        "Vượt ngưỡng 10.000.000 ₫"
      ]
    ],
    "sections": [
      [
        "Xem lại trước khi duyệt",
        "Nếu đơn thay đổi, bạn sẽ được yêu cầu xem lại",
        "Tránh duyệt nhầm phiên bản"
      ],
      [
        "Không đồng ý?",
        "Từ chối và ghi rõ lý do",
        "Đóng màn hình không đồng nghĩa từ chối"
      ],
      [
        "Quyết định được ghi lại",
        "Ai quyết định, khi nào và kết quả",
        "Quyền được kiểm tra khi xác nhận"
      ]
    ],
    "note": "Reject là action riêng. Timeout không tự coi là approval. Mobile giữ CTA dưới safe area."
  }
];
