export const screens = [
  {
    "id": "policy",
    "pack": "04-policies-commands",
    "surface": "Builder",
    "section": "Quy tắc & Quyền",
    "kind": "policy",
    "title": "Ai được xem đơn hàng?",
    "kicker": "ORDERS / READ POLICY",
    "description": "Chọn người, điều kiện và kiểm tra bằng tình huống mẫu.",
    "action": "Lưu quy tắc",
    "status": "Chưa áp dụng cho ứng dụng đã xuất bản",
    "fields": [
      [
        "Ai",
        "Quản lý hoặc người phụ trách"
      ],
      [
        "Được làm gì",
        "Xem đơn hàng"
      ],
      [
        "Điều kiện",
        "Đơn do chính mình phụ trách"
      ],
      [
        "Nếu không thỏa điều kiện",
        "Không cho phép"
      ]
    ],
    "sections": [
      [
        "Linh · Quản lý",
        "Được xem trong ví dụ",
        "Quyền tài khoản vẫn cần hợp lệ"
      ],
      [
        "An · Đơn An phụ trách",
        "Được xem trong ví dụ",
        "Chỉ hiện trường được cho phép"
      ],
      [
        "An · Đơn Linh phụ trách",
        "Không được xem",
        "Không mở quyền qua liên kết khách hàng"
      ]
    ],
    "note": "Runtime kiểm tenant boundary + current grants + app policy + restrictions; missing context phải deny."
  },
  {
    "id": "command",
    "pack": "04-policies-commands",
    "surface": "Builder",
    "section": "Quy tắc & Quyền",
    "kind": "flow",
    "title": "Gửi đơn hàng đúng điều kiện",
    "kicker": "HÀNH ĐỘNG / GỬI ĐƠN HÀNG",
    "description": "Chỉ cho gửi khi đơn đủ thông tin và người gửi có quyền.",
    "action": "Kiểm tra command",
    "status": "Hành động mẫu",
    "steps": [
      [
        "Quyền",
        "Người dùng được phép gửi đơn"
      ],
      [
        "Điều kiện",
        "Đơn là Nháp · có ít nhất 1 sản phẩm"
      ],
      [
        "Thay đổi",
        "Nháp → Đã gửi"
      ],
      [
        "Ghi nhận",
        "Lưu đơn và yêu cầu thông báo cùng nhau"
      ],
      [
        "Sau khi lưu",
        "Tiến hành gửi thông báo nếu đủ quyền"
      ]
    ],
    "inspector": [
      [
        "Input",
        "Ref<Orders>"
      ],
      [
        "Idempotency",
        "Request key + immutable intent"
      ],
      [
        "Xung đột",
        "409 / tải lại revision"
      ],
      [
        "Mutation",
        "Kiểm old + new state"
      ],
      [
        "Output",
        "Typed receipt"
      ]
    ],
    "note": "Không giữ transaction qua email, mạng hoặc người duyệt. Chưa có provider thật trong thiết kế. Committed retry trả original receipt dưới current grants dù live revision đã tiến."
  }
];
