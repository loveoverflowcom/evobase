export const screens = [
  {
    "id": "inbox",
    "pack": "10-messaging",
    "surface": "Runtime",
    "section": "Hộp thư",
    "kind": "chat",
    "title": "Minh An",
    "kicker": "INBOX / MINH AN",
    "description": "Trao đổi về ORD-1048 · Kênh Email",
    "action": "Gửi tin nhắn",
    "status": "Nội dung mẫu",
    "sections": [
      [
        "Minh An",
        "Cho mình xác nhận lịch giao ORD-1048 nhé",
        "Tin nhắn mẫu · 09:18"
      ],
      [
        "Linh",
        "Bên mình sẽ cập nhật sau khi đơn được duyệt",
        "Bản nháp · chưa gửi"
      ],
      [
        "Trạng thái gửi",
        "Chưa gửi",
        "Thông tin xác nhận chỉ được xem"
      ]
    ],
    "inspector": [
      [
        "Đơn liên quan",
        "ORD-1048"
      ],
      [
        "Kênh",
        "Email"
      ],
      [
        "Người tham gia",
        "Minh An · Linh"
      ],
      [
        "Thông tin gửi",
        "Chỉ đọc"
      ],
      [
        "Kênh khác",
        "Chỉ hiện khi đã kết nối"
      ]
    ],
    "note": "Transport-managed collections bảo vệ invariant; full chat/federation/E2EE không là MVP dependency."
  }
];
