# Local profile / recovery

Design/planning only; no implementation or provider evidence.

ADR support envelope cho portable execution, local unsent draft và restore.

## Screens
- offline

## Sequential prompts
- docs/work-plan/140-portability-recovery.md

## Acceptance
- [ ] Bounded codec/version/provenance and stable identity compatibility, .evobase extension ADR
- [ ] Local snapshot does not grant hosted authority; no falsely confirmed offline send
- [ ] Conflict needs review; reauth/revalidation/current permissions at sync
- [ ] Restore/export/receipts test: no revoked-grant resurrection or arbitrary external replay

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
