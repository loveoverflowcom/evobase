# Foundation / M3 Expressive shells

Design/planning only; no implementation or provider evidence.

Thống nhất AppSpec/host boundaries, source tokens, adaptive shells và trạng thái phiên. Provider sign-in journey chờ identity ADR.

## Screens
- workspace
- new-app
- settings
- states
- components

## Sequential prompts
- docs/work-plan/010-contracts-and-bootstrap.md

## Acceptance
- [ ] Token source→generated output→mounted consumer trace; không fork palette
- [ ] Workspace/Builder/Runtime navigation separate; compact Builder read-only summary
- [ ] Light/dark, focus, VI/EN, reduced motion, zoom/text-scale evidence
- [ ] Denied/session-expired giữ unsent draft; không coi settings là auth journey hoàn chỉnh

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
