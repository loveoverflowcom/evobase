# Preview / release / evolution

Design/planning only; no implementation or provider evidence.

Preview zero delivery, immutable checked release, impact/backfill/recovery trước activation.

## Screens
- view-builder
- preview
- publish
- migration

## Sequential prompts
- docs/work-plan/070-release-and-preview.md
- docs/work-plan/080-schema-evolution.md

## Acceptance
- [ ] Draft edits never activate; preview no live writes/no external dispatch
- [ ] AppSpec/model/data/binding/policy revisions separate; app instance pins release
- [ ] Type/required/backfill impact preview + atomic cutover/recovery proof; no-DDL still migration
- [ ] Live runs keep pinned version; rollback/restore does not unsend/replay effects or revive revoked grants

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
