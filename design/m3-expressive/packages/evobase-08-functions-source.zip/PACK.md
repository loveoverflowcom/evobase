# Durable declarative functions

Design/planning only; no implementation or provider evidence.

Finite typed steps, durable waits và trạng thái gửi chưa rõ kết quả.

## Screens
- functions
- run-detail

## Sequential prompts
- docs/work-plan/100-durable-functions.md

## Acceptance
- [ ] Pinned plan/run IDs/input snapshot/checkpoint/lease fencing and per-tenant budgets
- [ ] Transaction + event/outbox atomic; no network wait while holding DB transaction
- [ ] Lost ACK/duplicate/timer/restart/late-worker tests; bounded transient retries/permanent quarantine
- [ ] OutcomeUnknown + reconcile/correlation; current consent at dispatch; no exactly-once external promise

## Deferred
No default switch, merge, deploy, live migration, arbitrary provider delivery or legacy retirement.
